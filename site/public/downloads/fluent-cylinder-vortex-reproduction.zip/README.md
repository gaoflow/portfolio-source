# Fluent cylinder vortex — public reproduction bundle

This package rebuilds the public force-history metrics and figure without ANSYS Fluent or private course files.

```bash
python3 -m pip install -r requirements.txt
python3 scripts/rebuild.py
```

Inputs:

- `data/lift-history.csv` — retained digitised lift monitor;
- `data/drag-history.csv` — retained digitised drag monitor;
- `source-register.json` — final Fluent force-report endpoints and declared comparison values.

Outputs:

- `results/reproduction.json`;
- `results/public-force-history.svg`.

The private acquisition layer digitised archived Fluent screenshots and checked their endpoints against final force reports. This public package starts from the retained digitised histories and repeats every published gate.
