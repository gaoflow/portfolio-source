#!/usr/bin/env python3
"""Rebuild public vortex metrics/figure from retained digitised histories."""

from __future__ import annotations

import csv
import json
import statistics
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

PROJECT = Path(__file__).resolve().parents[1]
DATA = PROJECT / 'data'
RESULTS = PROJECT / 'results'
SOURCE = json.loads((PROJECT / 'source-register.json').read_text())['metrics']


def read_csv(path: Path) -> list[dict[str, float]]:
    with path.open() as handle:
        return [{key: float(value) for key, value in row.items()} for row in csv.DictReader(handle)]


lift = read_csv(DATA / 'lift-history.csv')
drag = read_csv(DATA / 'drag-history.csv')
developed = [row for row in lift if row['time_s'] > 40.0]
crossings = []
for left, right in zip(developed, developed[1:]):
    if left['cl'] < 0 <= right['cl']:
        fraction = -left['cl'] / (right['cl'] - left['cl'])
        crossings.append(left['time_s'] + fraction * (right['time_s'] - left['time_s']))
periods = [right - left for left, right in zip(crossings, crossings[1:])]
period = statistics.mean(periods)
period_std = statistics.pstdev(periods)
strouhal = 1.0 / period  # D=U=1 in the retained Re=150 case
final_lift = min(lift, key=lambda row: abs(row['time_s'] - 80.0))['cl']
final_drag = min(drag, key=lambda row: abs(row['time_s'] - 80.0))

gates = {
    'strouhalMatchesSourceRegister': abs(strouhal - SOURCE['strouhal']) <= 0.005,
    'periodRegularityBelowGate': period_std <= 0.15,
    'liftEndpointMatchesReport': abs(final_lift - SOURCE['finalReportedCl']) <= 0.02,
    'dragUnderpredictionVisible': (SOURCE['experimentalCd'] - SOURCE['finalReportedCd']) / SOURCE['experimentalCd'] >= 0.20,
}
if not all(gates.values()):
    raise RuntimeError(gates)

RESULTS.mkdir(parents=True, exist_ok=True)
summary = {
    'schemaVersion': 1,
    'retainedLiftSamples': len(lift),
    'retainedDragSamples': len(drag),
    'periodsS': periods,
    'meanPeriodS': period,
    'periodStdS': period_std,
    'strouhal': strouhal,
    'finalDigitisedCl': final_lift,
    'finalDigitisedCd': final_drag['cd'],
    'sourceRegister': SOURCE,
    'acceptance': gates,
}
(RESULTS / 'reproduction.json').write_text(json.dumps(summary, indent=2) + '\n')

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8.2, 5.4), sharex=True)
ax1.plot([row['time_s'] for row in lift], [row['cl'] for row in lift], color='#0f766e', lw=1.2)
ax1.axhline(0, color='#64748b', lw=0.7); ax1.set_ylabel('$C_L$'); ax1.set_title(f'Retained lift history: St={strouhal:.3f}', loc='left', fontsize=10); ax1.grid(alpha=0.22)
ax2.plot([row['time_s'] for row in drag], [row['cd'] for row in drag], color='#1e3a5f', lw=1.2)
ax2.axhline(SOURCE['experimentalCd'], color='#b91c1c', ls='--', lw=0.9, label='experiment ≈1.6')
ax2.set_ylabel('$C_D$'); ax2.set_xlabel('Flow time (s)'); ax2.set_title('Retained drag history and experimental gap', loc='left', fontsize=10); ax2.grid(alpha=0.22); ax2.legend(frameon=False)
fig.tight_layout(); fig.savefig(RESULTS / 'public-force-history.svg', format='svg'); plt.close(fig)
print(json.dumps(summary, indent=2))
